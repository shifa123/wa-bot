const express = require('express');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const cors = require('cors');
const fs = require('fs');
const app = express();
app.use(cors());
app.use(express.static('public'));
app.use(express.json());

const client = new Client({ authStrategy: new LocalAuth() });
let groupsCache = [];

client.on('qr', qr => qrcode.generate(qr, { small: true }));

client.on('ready', async () => {
  console.log('✅ WhatsApp client is ready.');
  const chats = await client.getChats();
  groupsCache = chats.filter(chat => chat.isGroup);
});

client.initialize();

app.get('/groups', (req, res) => {
  const sorted = groupsCache
    .map(g => ({ id: g.id._serialized, name: g.name, count: g.participants?.length || 0 }))
    .sort((a, b) => b.count - a.count);
  res.json(sorted);
});

app.get('/export/:groupId', async (req, res) => {
  const groupId = req.params.groupId;
  const group = groupsCache.find(g => g.id._serialized === groupId);
  if (!group) return res.status(404).send('Group not found');

  const members = group.participants;
  const csvLines = ['Sr. No,Number,Name,ID'];

  for (let i = 0; i < members.length; i++) {
    const m = members[i];
    const contact = await client.getContactById(m.id._serialized);
    const name = contact.pushname || contact.name || '';
    csvLines.push(`${i + 1},${m.id.user},${name},${m.id._serialized}`);
  }

  const csv = csvLines.join('\n');
  const safeGroupName = group.name.replace(/[^a-z0-9]/gi, '_');
  const filename = `${safeGroupName}_Contacts.csv`;

  fs.writeFileSync(`./${filename}`, csv);
  res.setHeader('Content-disposition', `attachment; filename=${filename}`);
  res.set('Content-Type', 'text/csv');
  res.send(csv);
});

app.listen(3000, () => {
  console.log('🚀 Server running at http://localhost:3000');
});