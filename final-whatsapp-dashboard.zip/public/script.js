function fetchGroups() {
  document.getElementById('loading-spinner').style.display = 'block';
  document.getElementById('group-section').style.display = 'none';
  document.getElementById('export-btn').style.display = 'none';
  document.getElementById('status').innerText = '';

  fetch('/groups')
    .then(res => res.json())
    .then(groups => {
      const select = document.getElementById('group-select');
      select.innerHTML = '';
      if (groups.length === 0) {
        select.innerHTML = '<option disabled>No groups found</option>';
      } else {
        groups.forEach(g => {
          const opt = document.createElement('option');
          opt.value = g.id;
          opt.textContent = `${g.name} (${g.count})`;
          select.appendChild(opt);
        });
        document.getElementById('export-btn').style.display = 'block';
      }
      document.getElementById('loading-spinner').style.display = 'none';
      document.getElementById('group-section').style.display = 'block';
    });
}

document.getElementById('refresh-btn').addEventListener('click', fetchGroups);
document.getElementById('export-btn').addEventListener('click', () => {
  const groupId = document.getElementById('group-select').value;
  if (!groupId) return;
  window.location.href = '/export/' + groupId;
});

document.getElementById('search-input').addEventListener('input', function () {
  const filter = this.value.toLowerCase();
  const options = document.querySelectorAll('#group-select option');
  options.forEach(opt => {
    opt.style.display = opt.textContent.toLowerCase().includes(filter) ? 'block' : 'none';
  });
});

fetchGroups();